<?php

// prevent this file from being accessed directly
if(!defined('WB_PATH')) die(header('Location: index.php'));

?>