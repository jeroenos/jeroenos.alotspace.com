//:Include a LibraryAdmin Preset
//:
include_once WB_PATH.'/modules/libraryadmin/include.php';
$backend_flag = false;
if ( empty( $lib ) )       { $lib    = 'libraryadmin'; }
if ( empty( $module ) )    { $module = NULL; }
if ( empty( $preset ) )    { $preset = NULL; }
if ( empty( $plugin ) )    { $plugin = NULL; }
if ( empty( $subdir ) )    { $subdir = NULL; }
if ( isset($backend) && $backend ) { $backend_flag = true; }
$new_page = includePreset( $wb_page_data, $lib, $preset, $module, $plugin, $backend_flag, NULL, $subdir );
if ( !empty($new_page) ) {
    $wb_page_data = $new_page;
}
return true;
