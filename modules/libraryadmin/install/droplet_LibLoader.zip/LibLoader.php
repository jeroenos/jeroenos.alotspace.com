//:Automatically include a LibraryAdmin Preset for the current page
//:Use: [[LibLoader]] 
include_once WB_PATH.'/modules/libraryadmin/include.php';
$new = libLoader( $wb_page_data, PAGE_ID );
if ( ! empty($new) ) { $wb_page_data = $new; }
return true;
